# HydroSim Examples Package v0.4.2

Welcome to HydroSim! This package contains everything you need to get started with water resources modeling.

## 🚀 Quick Start (Recommended for Beginners)

### Option 1: Self-Contained Starter (No external files needed)
```bash
pip install hydrosim matplotlib jupyter
python hydrosim_starter_notebook.py
```

### Option 2: Jupyter Notebook (Interactive)
```bash
pip install hydrosim matplotlib jupyter
jupyter notebook
# Copy sections from hydrosim_starter_notebook.py into notebook cells
```

## 📚 Example Files

### 🎯 Beginner Examples
- **`hydrosim_starter_notebook.py`** - Complete self-contained example (START HERE!)
- **`notebook_quick_start.py`** - Jupyter-optimized tutorial
- **`quick_start.py`** - Original quick start with YAML files

### 🏗️ Network Examples
- **`network_visualization_demo.py`** - Create interactive network diagrams
- **`storage_drawdown_demo.py`** - Reservoir operation scenarios
- **`results_visualization_demo.py`** - Analyze and plot results

### ⚙️ Configuration Files
- **`simple_network.yaml`** - Basic reservoir-city system
- **`complex_network.yaml`** - Multi-reservoir system with controls
- **`storage_drawdown_example.yaml`** - Storage operation examples

### 🌤️ Weather & Climate
- **`wgen_example.py`** - Weather generation with WGEN
- **`climate_builder_fetch_example.py`** - Download real climate data
- **`parameter_generator_example.py`** - Generate WGEN parameters

### 📊 Data Files
- **`climate_data.csv`** - Sample climate data
- **`inflow_data.csv`** - Sample river inflow (30 days)
- **`inflow_data_365.csv`** - Sample river inflow (1 year)
- **`wgen_params_template.csv`** - Weather generator parameters

## 🎓 Learning Path

### Step 1: Get Started
```bash
python hydrosim_starter_notebook.py
```

### Step 2: Explore Networks
```bash
python network_visualization_demo.py
python storage_drawdown_demo.py
```

### Step 3: Try YAML Configuration
```bash
python quick_start.py
```

### Step 4: Advanced Topics
```bash
python wgen_example.py
python climate_builder_fetch_example.py
```

## 📖 Documentation

- **Main Documentation**: https://github.com/jlillywh/hydrosim#readme
- **API Reference**: Use `help(hydrosim)` in Python
- **Interactive Help**: Use `hydrosim.help()` and `hydrosim.quick_start()`

## 🆘 Getting Help

```python
import hydrosim as hs
hs.help()        # Comprehensive help
hs.quick_start() # Interactive tutorial
hs.examples()    # Browse examples
hs.about()       # Version info
```

## 🐛 Issues & Support

- **GitHub Issues**: https://github.com/jlillywh/hydrosim/issues
- **Discussions**: https://github.com/jlillywh/hydrosim/discussions

## 📦 Installation

```bash
# Basic installation
pip install hydrosim

# With visualization support
pip install hydrosim matplotlib plotly

# For Jupyter notebooks
pip install hydrosim matplotlib plotly jupyter
```

---

**Happy modeling! 🌊**
